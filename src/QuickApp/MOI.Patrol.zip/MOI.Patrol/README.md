# Thaabet
Thaabet Tracking

Prerequisite
  1. VS 2017
  2. Visual  Code
  3. SQL SERVER

SETTING UP MACHINE

1. INSTALL NODE JS 
  https://nodejs.org/en/download/

2. INSTALL ANGULAR
  "npm install -g @angular/cli"
  
3. cd "ClientApp"

4. INSTALL all the required modules for the project
  "npm install --save"

5. If DevExpress Module is missing install it using the following command
  "npm install --save devextreme devextreme-angular"
  
6. To RUN application do the following 
  ng build
  ng serve
