﻿// ====================================================

// Email: support@ebenmonney.com
// ====================================================

using System;
using System.Linq;

namespace AssetManagement.ViewModels
{
    public class ClaimViewModel
    {
        public string Type { get; set; }
        public string Value { get; set; }
    }
}
